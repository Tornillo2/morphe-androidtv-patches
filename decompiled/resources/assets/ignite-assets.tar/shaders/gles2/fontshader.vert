#version 100
/* Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved. */

attribute highp vec2 a_position;

uniform highp vec2 resolution;
uniform highp vec2 glyph_atlas_size;
uniform highp vec4 transform;
uniform highp vec4 tex_transform;
uniform mediump vec2 rotation;

varying highp vec2 v_texcoord;

void main()
{
    highp vec2 normalized_tex_size = vec2(tex_transform.z / glyph_atlas_size.x,
            tex_transform.w / glyph_atlas_size.y);
    highp vec2 normalized_tex_pos_offset = vec2(tex_transform.x / glyph_atlas_size.x,
            tex_transform.y / glyph_atlas_size.y);

    v_texcoord = a_position * normalized_tex_size + normalized_tex_pos_offset;

    highp vec2 new_pos = mat2(rotation, -rotation.y, rotation.x) * (a_position * transform.zw) + transform.xy;

    gl_Position = vec4(new_pos.x / resolution.x - 1.0,
                       new_pos.y / -resolution.y + 1.0,
                       0.0,
                       1.0);
}
