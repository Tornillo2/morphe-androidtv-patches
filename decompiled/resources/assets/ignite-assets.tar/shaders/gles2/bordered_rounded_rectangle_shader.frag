#version 100
/* Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved. */

// u_color is the rgba color of this rectangle
uniform lowp vec4 u_color;
uniform mediump vec4 transform;
uniform mediump float radius;
uniform mediump float border_size;
uniform lowp vec4 border_color;

varying mediump vec2 pixel_pos;

mediump float roundedBoxSDF(mediump vec2 distToCenter, mediump vec2 maxDistToCenter, mediump float Radius) {
    mediump vec2 d = abs(distToCenter)-maxDistToCenter+Radius;
    return min(max(d.x, d.y), 0.0)+length(max(d,0.0))-Radius;
}

void main(void)
{
    mediump vec2 halfSize = transform.zw * 0.5;
    mediump float dist = roundedBoxSDF(pixel_pos.xy - halfSize, halfSize - 1.0, radius);
    mediump float smoothedAlpha = 1.0-smoothstep(0.0, 2.0, dist);
    mediump float borderAlpha = 1.0-smoothstep(border_size - 2.0, border_size, abs(dist));
    lowp vec4 finalColor = mix(u_color, border_color, borderAlpha);
    finalColor.a *= smoothedAlpha;
    gl_FragColor = finalColor;
}