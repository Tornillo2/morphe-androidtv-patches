#version 100
/* Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved. */

// u_texture, specify the texture unit we want to sample from.
uniform lowp sampler2D u_texture;
uniform mediump vec4 transform;
uniform mediump float radius;
uniform mediump float border_size;
uniform lowp vec4 border_color;
uniform lowp vec4 u_color_multiplier;

// pixel_pos is the position of this pixel in pixel unit which has been scaled to the desire size
// but hasn't been translated to the dst pos nor rotated. origin is top left.
varying mediump vec2 pixel_pos;
// v_texcoord is the texture coordinates.
varying mediump vec2 v_texcoord;

// Signed-distance-function, returns pixel distance to the edge for a rounded box shape
// Returns negative if the pixel is inside the shape
// See https://www.iquilezles.org/www/articles/distfunctions/distfunctions.htm for different
// shape SDFs
mediump float roundedBoxSDF(mediump vec2 distToCenter, mediump vec2 maxDistToCenter, mediump float Radius) {
    mediump vec2 d = abs(distToCenter)-maxDistToCenter+Radius;
    return min(max(d.x, d.y), 0.0)+length(max(d,0.0))-Radius;
}

void main(void)
{
    mediump vec2 halfSize = transform.zw * 0.5;
    mediump float dist = roundedBoxSDF(pixel_pos.xy - halfSize, halfSize - 1.0, radius);

    // Antialiasing for the edges
    mediump float smoothedAlpha = 1.0-smoothstep(0.0, 2.0, dist);
    lowp vec4 quadColor = (texture2D(u_texture, v_texcoord) * u_color_multiplier);

    // Antialiasing for inner edges of the border
    mediump float borderAlpha = 1.0-smoothstep(border_size - 2.0, border_size, abs(dist));
    lowp vec4 finalColor = mix(quadColor, border_color, borderAlpha);
    finalColor.a *= smoothedAlpha;
    gl_FragColor = finalColor;
}