#version 100
/* Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved. */
precision mediump float;
uniform mediump vec4 transform;
uniform mediump vec2 gradient_rotation;
uniform mediump vec2 u_dist;
uniform mediump float radius;
uniform lowp vec4 u_colors[4];
uniform mediump float percentages[4];
uniform mediump float inv_percentage_diffs[3];
varying mediump vec2 pixel_pos;

mediump float roundedBoxSDF(mediump vec2 distToCenter, mediump vec2 maxDistToCenter, mediump float Radius) {
    mediump vec2 d = abs(distToCenter)-maxDistToCenter+Radius;
    return length(max(d,0.0))-Radius;
}

void main()
{
    mediump vec2 halfSize = transform.zw * 0.5;
    mediump float dist = roundedBoxSDF(pixel_pos.xy - halfSize, halfSize, radius);
    mediump float t =  1.0-clamp(dist, 0.0, 1.0);

    float proj = dot(gradient_rotation, pixel_pos);

    // Clamp between lowest-highest percentages
    float perc = (proj - u_dist[0]) / (u_dist[1] - u_dist[0]);

    lowp vec4 finalCol;
    finalCol = mix(u_colors[0], u_colors[1], clamp((perc - percentages[0])*inv_percentage_diffs[0], 0.0, 1.0));
    finalCol = mix(finalCol, u_colors[2], clamp((perc - percentages[1])*inv_percentage_diffs[1], 0.0, 1.0));
    finalCol = mix(finalCol, u_colors[3], clamp((perc - percentages[2])*inv_percentage_diffs[2], 0.0, 1.0));
    finalCol.a *= t; 
    gl_FragColor = finalCol;
}