#version 100
/* Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved. */
precision mediump float;
uniform mediump vec4 transform;
uniform mediump vec2 center_pos;
uniform mediump float eccentricity;
uniform mediump float semi_minor_axis;
uniform mediump float radius;
uniform mediump vec2 major_unit_vec;
uniform lowp vec4 u_colors[4];
uniform mediump float percentages[4];
uniform mediump float inv_percentage_diffs[3];

varying mediump vec2 pixel_pos;

mediump float roundedBoxSDF(mediump vec2 distToCenter, mediump vec2 maxDistToCenter, mediump float Radius) {
    mediump vec2 d = abs(distToCenter)-maxDistToCenter+Radius;
    return length(max(d,0.0))-Radius;
}

mediump float avoidDivideByZero(mediump float value) {
    mediump float signValue = sign(value);
    return abs(signValue) / (value + (abs(signValue) - 1.0));
}

// For future ref: This is needed simply
// because in fragment shader, there will be a normalize() where
// intermediate results might not fit into mediump precision
// and cause INF results on most low end GPUs if the numbers
// are big enough. For example, mediump floats on ARM Mali-400 don't 
// seem to be able to go above ~16384.0.
mediump vec2 non_saturating_division(mediump vec2 v)
{
    mediump float factor = max(abs(v.x), abs(v.y));
    return v * avoidDivideByZero(factor);
}

void main()
{
    mediump vec2 halfSize = transform.zw * 0.5;
    mediump float dist = roundedBoxSDF(pixel_pos.xy - halfSize, halfSize, radius);
    mediump float t =  1.0-clamp(dist, 0.0, 1.0);

    mediump vec2 point_relative_coords = pixel_pos - center_pos;
    mediump vec2 non_saturated_diff = non_saturating_division(point_relative_coords);
    mediump float relative_coords_len = length(non_saturated_diff);
    mediump vec2 point_normalized_relative_coords = non_saturated_diff * avoidDivideByZero(relative_coords_len);
    mediump float proj = eccentricity * dot(point_normalized_relative_coords, major_unit_vec);

    // Most GPUs implement sqrt as 1/(inversesqrt). inversesqrt is one cycle for most
    // implementations. And we don't really need sqrt, we can just calculate
    // "ellipse_radius_for_point" by mult. instead of division.
    mediump float denominator = inversesqrt(1.0 - (proj * proj));
    mediump float ellipse_radius_for_point = semi_minor_axis * denominator;
    mediump float percentage_start = length(point_relative_coords / ellipse_radius_for_point);

    lowp vec4 finalCol;
    finalCol = mix(u_colors[0], u_colors[1], clamp((percentage_start - percentages[0])*inv_percentage_diffs[0], 0.0, 1.0));
    finalCol = mix(finalCol, u_colors[2], clamp((percentage_start - percentages[1])*inv_percentage_diffs[1], 0.0, 1.0));
    finalCol = mix(finalCol, u_colors[3], clamp((percentage_start - percentages[2])*inv_percentage_diffs[2], 0.0, 1.0));
    finalCol.a *= t; 
    gl_FragColor = finalCol;
}