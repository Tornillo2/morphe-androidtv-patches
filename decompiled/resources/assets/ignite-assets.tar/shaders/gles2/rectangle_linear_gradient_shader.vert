#version 100
/* Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved. */
attribute highp vec2 a_position;
uniform mediump vec2 resolution;
uniform mediump vec4 transform;
uniform mediump vec2 rotation;
varying mediump vec2 pixel_pos;

void main(void)
{
    pixel_pos = (a_position * transform.zw);
    vec2 new_pos = a_position * transform.zw - 0.5 * transform.zw;
    mat2 rotation_matrix = mat2(rotation, -rotation.y, rotation.x);
    new_pos = rotation_matrix * new_pos
    + 0.5 * transform.zw + transform.xy;
    gl_Position = vec4(new_pos.x  / resolution.x - 1.0,
    new_pos.y  / -resolution.y + 1.0,
    0.0,
    1.0);
}