#version 100
/* Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved. */

attribute highp vec2 a_position;

uniform mediump vec2 resolution;
uniform mediump vec4 transform;
uniform mediump vec4 tex_transform;
uniform mediump vec2 rotation;

varying mediump vec2 v_texcoord;

void main()
{
    v_texcoord.xy = a_position * tex_transform.zw + tex_transform.xy;

    vec2 new_pos = a_position * transform.zw;

    new_pos = mat2(rotation, -rotation.y, rotation.x) * (new_pos - 0.5 * transform.zw)
            + 0.5 * transform.zw + transform.xy;

    gl_Position = vec4(new_pos.x / resolution.x - 1.0,
                       new_pos.y / -resolution.y + 1.0,
                       0.0,
                       1.0);
}