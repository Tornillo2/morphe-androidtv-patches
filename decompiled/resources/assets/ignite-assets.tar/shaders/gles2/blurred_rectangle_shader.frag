#version 100
/* Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved. */

uniform highp vec2 resolution;
uniform highp vec4 transform;

// u_color is the rgba color of this rectangle
uniform highp vec4 u_color;

uniform mediump vec4 u_radius;
uniform mediump float u_gauss_sigma;
uniform mediump float u_gauss_filter_size;

varying highp vec2 local_space_pos;

// A standard gaussian function, used for weighting samples
highp float gaussian(highp float x, highp float sigma) {
    const highp float pi = 3.141592653589793;
    return exp(-(x * x) / (2.0 * sigma * sigma)) / (sqrt(2.0 * pi) * sigma);
}

// This approximates the error function, needed for the gaussian integral
highp vec2 erf(highp vec2 x) {
    highp vec2 s = sign(x), a = abs(x);
    x = 1.0 + (0.278393 + (0.230389 + 0.078108 * (a * a)) * a) * a;
    x *= x;
    return s - s / (x * x);
}

/**
 * Compute the blur factor along the X axis. This uses the fact that the blur factor in
 * one axis can be approximated by using the 'erf' function.
 *
 * Notes:
 * This function will calculate the indefinite integral in two points spaced by the row width
 * (i.e., the width of the rectangle or less in the rows that are part of the rounded corners).
 * In the cases where the sigma is small compared to the rectangle width, it's fine to only compute
 * the integral of `x`, but for larger sigma values, the result will be innacurate.
 * Consider the case for x values greater than zero:
 *    For those cases, we want to use the integral of the gaussian function (let's call F(x)) with the
 *    mean parameter as the right edge (i.e., halfSize.x). If the rectangle was infinitely large (to the left)
 *    the blur factor would be exactly F(x - halfSize.x). However, only the pixels between halfSize.x and 
 *    halfSize.x - width (which is -halfSize.x) contribute to the blur factor. 
 *    Hence, the blur factor for x is: 
 *         blurFactorAxisX(x) = F(x + halfSize.x) - F(x - halfSize.x).
 * The cases for x values lesser than zero, the reasoning is the same and the formula will end-up being the same.
 */
highp float blurFactorAxisX(highp float x, highp float y, lowp float sigma, lowp vec2 corner, highp vec2 halfSize) {
    highp vec2 delta = min(halfSize.y - corner - abs(y), vec2(0.0));
    highp vec2 curved = halfSize.x - corner + sqrt(max(vec2(0.0), corner * corner - delta * delta));
    highp vec2 integral = 0.5 + 0.5 * erf((x + vec2(-curved.x, curved.y)) * (sqrt(0.5) / sigma));
    return integral.y - integral.x;
}

/**
 * Return the blur factor for a box from lower to upper.
 * 
 * Notes:
 * This function will use an analytical solution to compute the blur factor in the x axis and collect 4
 * samples along the y axis and multiply by Gaussian(Y).
 */
highp float blurFactor(highp vec2 lower, highp vec2 upper, highp vec2 point, lowp float sigma, lowp vec4 corner) {
    highp vec2 halfSize = (upper - lower) * 0.5;

    // The signal is only non-zero in a limited range, so don't waste samples
    highp float low = point.y - halfSize.y;
    highp float high = point.y + halfSize.y;
    lowp float start = clamp(-3.0 * sigma, low, high);
    lowp float end = clamp(3.0 * sigma, low, high);

    lowp float st = (end - start) / 4.0;
    lowp float y = start + st * 0.5;
    highp float value = 0.0;
    for (int i = 0; i < 4; i++) {
        // step will either return 0 or 1, so the mix will either be corner.yx if the relative y position is positive
        // and corner.wz otherwise.
        lowp vec2 xCorner = mix(corner.yx, corner.wz, step(0.0, point.y - y));
        value += blurFactorAxisX(point.x, point.y - y, sigma, xCorner, halfSize) * gaussian(y, sigma) * st;
        y += st;
    }

    return value;
}

void main(void)
{
    highp vec2 lower = transform.xy + u_gauss_filter_size;
    highp vec2 upper = transform.xy + transform.zw - u_gauss_filter_size;

    highp float boxFactor = blurFactor(lower, upper, local_space_pos, u_gauss_sigma, u_radius);

    gl_FragColor = vec4(u_color.rgb,  u_color.a * boxFactor);
}
