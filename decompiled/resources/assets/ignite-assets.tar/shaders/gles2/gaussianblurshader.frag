#version 100
/* Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved. */

/**
 * For more info: http://rastergrid.com/blog/2010/09/efficient-gaussian-blur-with-linear-sampling
 */
const int MAX_FILTER_SIZE = 3;

uniform lowp sampler2D u_texture;
uniform mediump vec4 transform;
uniform mediump vec4  u_color_multiplier;

varying highp vec2 v_texcoord;

uniform mediump float u_gauss_offsets[MAX_FILTER_SIZE];
uniform mediump float u_gauss_weights[MAX_FILTER_SIZE];
// 1.0 for X-axis blur, 0.0 for Y-axis blur
uniform mediump float u_gauss_filter_direction;

void main()
{
    mediump vec4 fragColor = texture2D(u_texture, v_texcoord) * u_gauss_weights[0];
    for (int i=1; i<MAX_FILTER_SIZE; i++) {
        mediump float offsetX = u_gauss_offsets[i] / transform.z;
        mediump float offsetY = u_gauss_offsets[i] / transform.w;
        highp vec2 offset = vec2(u_gauss_filter_direction * offsetX, (1.0 - u_gauss_filter_direction) * offsetY);
        fragColor +=
            texture2D(u_texture, (v_texcoord + offset))
                * u_gauss_weights[i];
        fragColor +=
            texture2D(u_texture, (v_texcoord - offset))
                * u_gauss_weights[i];
    }

    gl_FragColor = fragColor * u_color_multiplier;
}
