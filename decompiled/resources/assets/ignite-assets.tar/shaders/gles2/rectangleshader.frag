#version 100
/* Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved. */
// u_color is the rgba color of this rectangle
uniform lowp vec4 u_color;

void main(void)
{
    gl_FragColor = u_color;
}