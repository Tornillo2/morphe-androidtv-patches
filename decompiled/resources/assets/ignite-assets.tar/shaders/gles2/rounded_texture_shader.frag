#version 100
/* Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved. */

uniform lowp sampler2D u_texture;
uniform mediump vec4 transform;
uniform mediump float radius;
uniform lowp vec4 u_color_multiplier;
varying mediump vec2 pixel_pos;
varying mediump vec2 v_texcoord;

mediump float roundedBoxSDF(mediump vec2 distToCenter, mediump vec2 maxDistToCenter, mediump float Radius) {
    mediump vec2 d = abs(distToCenter)-maxDistToCenter+Radius;
    return length(max(d,0.0))-Radius;
}

void main(void)
{
    mediump vec2 halfSize = transform.zw * 0.5;
    mediump float dist = roundedBoxSDF(pixel_pos.xy - halfSize, halfSize - 1.0, radius);

    // Antialiasing for the edges
    mediump float smoothedAlpha = 1.0-smoothstep(0.0, 2.0, dist);
    lowp vec4 quadColor = (texture2D(u_texture, v_texcoord) * u_color_multiplier);
    quadColor.a *= smoothedAlpha;
    gl_FragColor = quadColor;
}