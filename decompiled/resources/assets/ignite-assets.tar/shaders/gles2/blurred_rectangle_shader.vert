#version 100
/* Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved. */

attribute highp vec2 a_position;

uniform highp vec2 resolution;
uniform highp vec4 transform;
uniform highp vec2 rotation;

varying highp vec2 local_space_pos;

void main(void)
{
    // First convert a_position to screen space and then transform to local space (where the origin
    // is the center of the transform, i.e., transform.xy + 0.5 * transform.zw)
    local_space_pos = (a_position - 0.5) * transform.zw;
    
    vec2 new_pos = a_position * transform.zw - 0.5 * transform.zw;
    new_pos = mat2(rotation, -rotation.y, rotation.x) * new_pos
                  + 0.5 * transform.zw + transform.xy;

    gl_Position = vec4(new_pos.x  / resolution.x - 1.0,
                       new_pos.y  / -resolution.y + 1.0,
                       0.0,
                       1.0);
}
