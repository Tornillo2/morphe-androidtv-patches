#version 100
/* Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved. */

attribute mediump vec2 a_position;

uniform highp vec2 resolution;
uniform mediump vec4 transform;
uniform mediump vec4 tex_transform;

varying mediump vec2 v_texcoord;

void main()
{
    v_texcoord = a_position * tex_transform.zw + tex_transform.xy;

    vec2 new_pos = a_position * transform.zw + transform.xy;

    gl_Position = vec4(new_pos.x / resolution.x - 1.0,
                       new_pos.y / -resolution.y + 1.0,
                       0.0,
                       1.0);
}