#version 100
/* Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved. */
uniform lowp sampler2D u_texture;
uniform lowp vec4 u_color_multiplier;

varying mediump vec2 v_texcoord;

void main()
{
    gl_FragColor = texture2D(u_texture, v_texcoord) * u_color_multiplier;
}
