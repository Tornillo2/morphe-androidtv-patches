#version 100
/* Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved. */

uniform lowp sampler2D u_texture;
uniform lowp vec4 u_color;

varying highp vec2 v_texcoord;

void main()
{
    lowp vec4 color = texture2D(u_texture, v_texcoord);
    gl_FragColor = vec4(1, 1, 1, color.r) * u_color;
}
